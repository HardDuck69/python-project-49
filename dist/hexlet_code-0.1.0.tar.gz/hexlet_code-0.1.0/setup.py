# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts', 'brain_games.some_games']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Brain games: 5 games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/HardDuck69/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/HardDuck69/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/a99a88d28ad37a79dbf6/maintainability)](https://codeclimate.com/github/HardDuck69/python-project-49)\n[![github-actions](https://github.com/HardDuck69/python-project-49/actions/workflows/github-actions.yml/badge.svg)](https://github.com/HardDuck69/python-project-49/actions/workflows/github-actions.yml)\n\n\n[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&pause=1000&color=C50000&center=true&width=435&lines=Hello+there!+I\'m+HardDuck69;Look+at+my+first+python-project)](https://git.io/typing-svg)\n\n\n<h1 align="center">Brain Games (Игры разума)</h1>\n<h3 align="center">В коллекции: 5 игр &#129414;</h3>\n\n\nСетап:\nPython ^3.10\nFlake8 ^6.0.0\nPrompt ^0.4.1\nPoetry 1.2.2\n\n\nИспользуемые команды Makefile: \nMake install - установка пакетов #poetry install\nMake build - сборка и отладка пакетов #poetry build\nMake package-install - установка пакетов в систему #poetry -m pip install --force-reinstall dist/*.whl\n\n\n\nКоманды запуска к играм:\n\n\n```brain-prime``` — игра «Простое ли число?»\n\n```brain-progression``` — игра «Арифмитическая прогрессия»\n\n```brain-even``` — игра «Проверка на чётность»\n\n```brain-calc``` — игра Калькулятор»\n\n```brain-gcd``` — игра Игра НОД»\n\n\nУстановка и первый запуск:\n\n[![asciicast](https://asciinema.org/a/tj56lutGahNIpGVURAkfkSdCs.svg)](https://asciinema.org/a/tj56lutGahNIpGVURAkfkSdCs)\n\n\nДемо всех игр:\n\nbrain-prime demo:\n\n\n[![asciicast](https://asciinema.org/a/CXQeqrugLLD7Tk8svncWJqMym.svg)](https://asciinema.org/a/CXQeqrugLLD7Tk8svncWJqMym)\n\n\nbrain-progression demo:\n\n\n[![asciicast](https://asciinema.org/a/fTGEl5Sc9SwF5Yz7L9lcie5Ep.svg)](https://asciinema.org/a/fTGEl5Sc9SwF5Yz7L9lcie5Ep)\n\n\nbrain-gcd demo:\n\n[![asciicast](https://asciinema.org/a/gAigiXDz0r9uivMCXmf1H5w1p.svg)](https://asciinema.org/a/gAigiXDz0r9uivMCXmf1H5w1p)\n\n\nbrain-calc demo:\n\n\n[![asciicast](https://asciinema.org/a/x3rxGJ7O2pvR3YThhfYPnlhXQ.svg)](https://asciinema.org/a/x3rxGJ7O2pvR3YThhfYPnlhXQ)\n\n\nbrain-even demo:\n\n[![asciicast](https://asciinema.org/a/MdLoIVXybSoCEkQYcADB2Y6gA.svg)](https://asciinema.org/a/MdLoIVXybSoCEkQYcADB2Y6gA)\n',
    'author': 'HardDuck69',
    'author_email': 'tmu1408@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/HardDuck69/python-project-49.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
