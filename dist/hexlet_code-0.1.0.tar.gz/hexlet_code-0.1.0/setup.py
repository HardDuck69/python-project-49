# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts', 'brain_games.some_games']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_progression:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/HardDuck69/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/HardDuck69/python-project-49/actions)\n\nbrain-progression demo:\n<a href="https://asciinema.org/a/fTGEl5Sc9SwF5Yz7L9lcie5Ep" target="_blank"><img src="https://asciinema.org/a/fTGEl5Sc9SwF5Yz7L9lcie5Ep.svg" /></a>\n\nbrain-gcd demo:\n<a href="https://asciinema.org/a/gAigiXDz0r9uivMCXmf1H5w1p" target="_blank"><img src="https://asciinema.org/a/gAigiXDz0r9uivMCXmf1H5w1p.svg" /></a>\n\n\nbrain-calc demo:\n<a href="https://asciinema.org/a/x3rxGJ7O2pvR3YThhfYPnlhXQ" target="_blank"><img src="https://asciinema.org/a/x3rxGJ7O2pvR3YThhfYPnlhXQ.svg" /></a>\n\n\nbrain-even demo:\n<a href="https://asciinema.org/a/542386" target="_blank"><img src="https://asciinema.org/a/542386.svg" /></a>\n',
    'author': 'hardduck',
    'author_email': 'tmu1408@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
