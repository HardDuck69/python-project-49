### Hexlet tests and linter status:
[![Actions Status](https://github.com/HardDuck69/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/HardDuck69/python-project-49/actions)

brain-progression demo:
<a href="https://asciinema.org/a/fTGEl5Sc9SwF5Yz7L9lcie5Ep" target="_blank"><img src="https://asciinema.org/a/fTGEl5Sc9SwF5Yz7L9lcie5Ep.svg" /></a>

brain-gcd demo:
<a href="https://asciinema.org/a/gAigiXDz0r9uivMCXmf1H5w1p" target="_blank"><img src="https://asciinema.org/a/gAigiXDz0r9uivMCXmf1H5w1p.svg" /></a>


brain-calc demo:
<a href="https://asciinema.org/a/x3rxGJ7O2pvR3YThhfYPnlhXQ" target="_blank"><img src="https://asciinema.org/a/x3rxGJ7O2pvR3YThhfYPnlhXQ.svg" /></a>


brain-even demo:
<a href="https://asciinema.org/a/542386" target="_blank"><img src="https://asciinema.org/a/542386.svg" /></a>
